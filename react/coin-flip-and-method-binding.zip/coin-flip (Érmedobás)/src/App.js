import React from 'react';
import logo from './logo.svg';
import './App.css';
import CoinContainer from "./CoinContainer"

function App() {
  return (
    <div className="App">
      <CoinContainer />
    </div>
  );
}

export default App;
