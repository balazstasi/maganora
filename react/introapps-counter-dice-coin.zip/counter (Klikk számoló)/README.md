# Indítás
``npm install``, utána ``npm start``