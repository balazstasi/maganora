# Indítás
``npm install`` aztán ``npm start``