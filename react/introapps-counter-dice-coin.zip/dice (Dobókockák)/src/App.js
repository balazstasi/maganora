import React from "react";
import RollDice from "./RollDice";

function App() {
  return (
    <div>
      <RollDice />
    </div>
  );
}

export default App;
