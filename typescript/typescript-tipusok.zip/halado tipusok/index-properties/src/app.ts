interface ErrorContainer {
  [prop: string]: string;
}

const errorBag: ErrorContainer = {
  email: "Not a Valid Email Adress",
  username: "Not a Valid Username",
};
