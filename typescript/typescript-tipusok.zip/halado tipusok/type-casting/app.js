var userInputElement = document.getElementById("user-input");
if (userInputElement) {
    userInputElement.value = "Hello World!";
}
