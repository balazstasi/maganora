var _a;
var fetchedData = {
    id: "12312313",
    name: "Balazs",
    job: {
        title: undefined,
        description: "React Developer"
    }
};
console.log((_a = fetchedData === null || fetchedData === void 0 ? void 0 : fetchedData.job) === null || _a === void 0 ? void 0 : _a.title);
var userInput = undefined;
var storedData = userInput !== null && userInput !== void 0 ? userInput : "DEFAULT";
console.log(storedData);
